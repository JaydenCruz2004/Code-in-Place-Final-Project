import cha.*;
import cha.action.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.text.DecimalFormat;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.*;
import org.jfree.data.general.*;
import org.jfree.data.xy.*;
import static java.awt.Color.*;
import static java.awt.Font.*;
import static java.lang.Math.*;
import static javax.swing.SwingConstants.*;

public class LiloStitch
extends CHApplet
{
    Random gen;
    int horizon;
    int suns;
    Sky sky;
    Sun sun;
    Color sands;
    Color sandsl;
    Color bottoms;
    Color speckle;
    Color sblue;
    Color dblue;
    Color moonn;
    CHOval [] sandd;
    CHOval [] star;
    CHOval moon;
    CHImage bird;
    CHImage palmTreePng;
    CHImage lilostitch;
    CHClip jumping;
    CHClip rooster;
    CHClip crickets;
    private class Morning
    extends CHAction {
        public void step() {
            int bRed;
            int bBlue;
            int bGreen;
            bRed = min(255, counter * 2);
            bBlue = counter;
            bGreen = counter;
            Color bottomColor;
            bottomColor = new Color(bRed, bBlue, bGreen); 
            sky.setBottom(bottomColor);
            int tRed;
            int tBlue;
            int tGreen;
            tRed = min(255, counter * 1);
            tBlue = counter;
            tGreen = counter;
            Color topColor;
            topColor = new Color(tRed, tBlue, tGreen);
            sky.setTop(topColor);
            sky.repaint();
            
            
            
            
            
                        
            
            
            
            

        }
        public void after(){
            sky.setTop(sblue);
            rooster.play();
            moon.setVisible(false);
            bird.setVisible(true);
            
        }
    }
    private class Night
    extends CHAction {
        public void step() {
            int bRed;
            int bBlue;
            int bGreen;
            bRed = min(255, counter * 2);
            bBlue = counter;
            bGreen = counter;
            Color bottomColor;
            bottomColor = new Color(bRed, bBlue, bGreen); 
            sky.setBottom(bottomColor);
            int tRed;
            int tBlue;
            int tGreen;
            tRed = min(255, counter * 1);
            tBlue = counter;
            tGreen = counter;
            Color topColor;
            topColor = new Color(tRed, tBlue, tGreen);
            sky.setTop(topColor);
            sky.repaint();
            
            
            
          

        }
        public void after(){
           sky.setBottom(black);
           sky.setTop(dblue);
           crickets.play();
           moon.setVisible(true);
           bird.setVisible(false);
           
           
           
        }
    }
    class Hop
    extends CHAction {
        public void step() {
            
            for(int i = 0; i <  5; i++) {
             lilostitch.moveOneStep();
             
             sleep();
            }
            
        }
        public void after(){
            jumping.play();
        }
    } 
    class Fly
    extends CHAction {
        public void step(){
            for(int i = 0; i <  400; i++) {
             bird.moveOneStep();
             
             sleep();
            }
            
        }
    }
    class Reset
    extends CHAction {
        public void step() {
          lilostitch.setBounds(0, 350, 180, 200);
          lilostitch.setVelocity(2, -3);
          lilostitch.setAcceleration(0, 0.02);
          
          bird.setBounds(710, 100, 100, 135);
          bird.setVelocity(-2,0);
          
        }
    }
    public void init() {
        
        gen = new Random();
        sands = new Color(231, 215, 190);
        sandsl = new Color(174, 155, 125);
        bottoms = new Color(255, 201, 34);
        speckle = new Color(181,154,106);
        sblue = new Color(0, 153, 255);
        dblue = new Color(0, 51, 102);
        moonn = new Color(254, 252,215);
        
        
        
        
        jumping = new CHClip();
        add(jumping);
        jumping.setFile("jumping.wav");
        
        rooster = new CHClip();
        add(rooster);
        rooster.setFile("rooster.wav");
        
        crickets = new CHClip();
        add(crickets);
        crickets.setFile("crickets.mp3");
        star = new CHOval[500];
        
        
       
        CHRectangle sand;
        sand = new CHRectangle();
        add(sand,0);
        int sh;
        sh = getHeight() - horizon;
        sand.setBounds(0, horizon, getWidth(), sh);
        sand.setBackground(sands);
        sand.setForeground(sandsl);
        
        sandd = new CHOval[500];
        for(int i = 0; i<sandd.length; i++) {
            gen = new Random();
            sandd[i] = new CHOval();
            add(sandd[i],0);
            int x;
            int y;
            int ss;
            ss = getHeight() - horizon;
            x = gen.nextInt(1000)-90;
            y= gen.nextInt(1000)-90;
            sandd[i].setBounds(x, y, 3, 3);
            
           
            sandd[i].setBackground(speckle);
            sandd[i].setForeground(speckle);
        }
        
        
        
        
        gen = new Random();
        horizon = getHeight() * 4 / 5;        
        sky = new Sky();
        add(sky,0);
        sky.setBounds(0, 0, getWidth(), horizon);
        
        gen = new Random();
        suns = getHeight() * 1 / 4;        
        sun = new Sun();
        add(sun,0);
        sun.setBounds(0, 0, getWidth(), suns);
        
        CHOval sun;
        sun = new CHOval();
        add(sun,0);
        sun.setBounds(695, 3, 105, 103);
        sun.setForeground(bottoms);
        
        moon = new CHOval();
        add(moon,0);
        moon.setBounds(695, 3, 105, 103);
        moon.setBackground(moonn);
        moon.setVisible(false);
        
        Morning morn;
        morn = new Morning();
        add(morn);
        morn.setText("Morning");
        
        CHButton dbutton;
        dbutton = new CHButton();
        add(dbutton,0);
        dbutton.setAction(morn);
        dbutton.setBounds(730, 560, 70,35);
        
        morn.setLimit(250);
        morn.setDelay(70);
        
        Night night;
        night = new Night();
        add(night);
        night.setText("Night");
        
        CHButton nbutton;
        nbutton = new CHButton();
        add(nbutton,0);
        nbutton.setAction(night);
        nbutton.setBounds(0, 560, 70,35);
        
        Reset rAction;
        rAction = new Reset();
        add(rAction);
        rAction.setText("Reset");
        rAction.setLimit(60);
        
        
        CHButton rButton;
        rButton = new CHButton();
        add(rButton, 0);
        rButton.setBounds(0, 538, 72, 25);
        rButton.setAction(rAction);
        
        night.setLimit(250);
        night.setDelay(70);
        
        CHImage palmTreePng;
        palmTreePng = new CHImage();
        add(palmTreePng,0);
        palmTreePng.setFile("palm-tree-png.png");
        palmTreePng.setBounds(560, 210, 260, 280);
        
        
        
        
        lilostitch = new CHImage();
        add(lilostitch,0);
        lilostitch.setFile("lilostitch.png");
        lilostitch.setBounds(0, 350, 180, 200);
        lilostitch.setVelocity(2, -3);
        lilostitch.setAcceleration(0, 0.02);
        
        bird = new CHImage();
        add(bird,0);
        bird.setFile("bird.gif");
        bird.setBounds(710, 100, 100, 135);
        bird.setVelocity(-2,0);
        bird.setVisible(false);
        
        
        
        
        Hop hAction;
        hAction = new Hop();
        add(hAction);
        hAction.setText("Jump");
        hAction.setLimit(60);
        
        
        CHButton hButton;
        hButton = new CHButton();
        add(hButton, 0);
        hButton.setBounds(725, 536, 87, 29);
        hButton.setAction(hAction);
        
        Fly fAction;
        fAction = new Fly();
        add(fAction);
        fAction.setText("Fly");
        hAction.setLimit(60);
        
        CHButton fButton;
        fButton = new CHButton();
        add(fButton, 0);
        fButton.setBounds(725, 515, 87, 29);
        fButton.setAction(fAction);
        
        
        
        
     
        
    } // end of init - DO NOT REMOVE
    
    /***********************************************************
     * CAREFULLY Change the code below this line.
     ***********************************************************/
    public static void run() {
        int width = 800;
        int height = 600;
        CHApplet applet = new LiloStitch(); 
        applet.run(width, height);
    }
    
    private LiloStitch(){}
    
} // end of main class - DO NOT REMOVE