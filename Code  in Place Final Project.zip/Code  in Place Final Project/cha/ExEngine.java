package cha;
import java.io.InputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
Run an example without displaying the source code.
To use this class:
<ol>
<li>In the solutions/<i>NNproject</i>-solved folder:</li>
<ol>
<li>Add a main method to the solved class.</li>
<li>Export the project to example.jar</li>
</ol>
<li>In the public/<i>NNproject</i> folder:</li>
<ol>
<li>Copy (or link) Example.class into the folder.</li>
<li>Move example<i>N</i>.jar into the folder.<br>
N=1 for the solved example,<br>
N=0 for the starting canvas,<br>
N=2+ for variations</li>
<li>Right-click this method and choose <b>run()</b>.</li>
</ol>
</ol>

@author William H. Hooper
@version 2022-01-05
 */
public class ExEngine
{
    private ExEngine(){}
    
    /**
     * Run the specified example.
     * @param n the example suffix.
     * For example, run(2) will run "example2.jar".
     */
    public static void run(int n)
    {
        String filename = "example" + n + ".jar";        
        File f = new File(filename);
        if(!f.exists()) { 
            System.out.println(filename + " is missing.");
            return;
        }

        Process proc = null;
        try {
            // Run a java app in a separate system process
            proc = Runtime.getRuntime()
            .exec("java -jar " + filename + " -get t");

            BufferedReader stdInput = new BufferedReader(new 
                    InputStreamReader(proc.getInputStream()));

            BufferedReader stdError = new BufferedReader(new 
                    InputStreamReader(proc.getErrorStream()));

            boolean first = true;
            // read the output from the command
            String s = null;
            while ((s = stdInput.readLine()) != null) {
                if(first) {
                    System.out.println("\f");
                }
                System.out.println(s);
                first = false;
            }

            // read any errors from the attempted command
            while ((s = stdError.readLine()) != null) {
                if(first) {
                    System.err.println("\f");
                }
                System.err.println(s);
                first = false;
            }
        } catch(Exception e) {
            System.out.println(e);
        }
    }
}
