import cha.*;
import java.awt.*;
import java.awt.geom.*;

import static java.lang.Math.*;
import static java.awt.Color.*;

public class Sun
extends CHComponent {
    Color tops, bottoms;
    
    public void init() {
        bottoms = new Color(253, 94, 83);
        tops = new Color(255, 201, 34);
    }
    
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        Dimension size = getSize();
        int ww = size.width;
        int hh = size.height;
        
        GradientPaint gp = new GradientPaint(
            0, hh/8, tops,
            0, hh, bottoms);
        g2d.setPaint(gp);        
        
        g2d.fillOval(695, 3, 105, 103);
        
        super.paintComponent(g);
    }
    
    public void setBottom(Color c) {
        bottoms = c;
    }
    
    public void setTop(Color c) {
        tops = c;
    }
}
