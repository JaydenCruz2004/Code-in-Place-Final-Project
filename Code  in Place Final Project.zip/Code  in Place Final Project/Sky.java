import cha.*;
import java.awt.*;
import java.awt.geom.*;

import static java.lang.Math.*;
import static java.awt.Color.*;

public class Sky
extends CHComponent {
    Color top, bottom;
    
    public void init() {
        bottom = new Color(227, 157, 151);
        top = new Color(212, 142, 205);
    }
    
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        Dimension size = getSize();
        int w = size.width;
        int h = size.height;
        
        GradientPaint gp = new GradientPaint(
            0, h/3, top,
            0, h, bottom);
        g2d.setPaint(gp);
        
        g2d.fillRect(0, 0, w, h);
        
        super.paintComponent(g);
    }
    
    public void setBottom(Color c) {
        bottom = c;
    }
    
    public void setTop(Color c) {
        top = c;
    }
}
