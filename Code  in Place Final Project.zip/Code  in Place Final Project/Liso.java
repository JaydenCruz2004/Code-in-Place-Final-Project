
import cha.*;

import static java.awt.Color.*;

public class Liso
extends CHContainer {
    public void init() {
        

        CHImage lilostitch;
        lilostitch = new CHImage();
        add(lilostitch);
        lilostitch.setFile("lilostitch.png");
        lilostitch.setBounds(400, 210, 180, 200);
        
        
        
    }
}